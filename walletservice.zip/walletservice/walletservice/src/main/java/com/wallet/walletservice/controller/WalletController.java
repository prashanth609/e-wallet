package com.wallet.walletservice.controller;

import com.wallet.walletservice.bean.WalletDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WalletController {

    @GetMapping("/getWalletData/{walletId}")
    public WalletDetails getWalletData(@PathVariable("walletId")Integer walletId){
     return new WalletDetails(walletId,200.00,"$",10001);
    }
}
