package com.wallet.walletservice.bean;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class WalletDetails {
    private Integer walletId;
    private Double balance;
    private String currency;
    private Integer userid;
}
